"""
UI module for OSM AI Agent plugin.
Contains UI forms and resources.
"""

