"""
Qt resources file for OSM AI Agent plugin.
This file is generated from resources.qrc
"""

# This is a placeholder file. In a real deployment, you would generate this file
# using pyrcc5 or similar tool:
# pyrcc5 -o resources.py resources.qrc

# For now, this empty file prevents import errors

