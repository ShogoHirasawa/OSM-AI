"""
Core module for OSM AI Agent plugin.
Contains business logic for LLM, Overpass API, and QGIS integration.
"""

