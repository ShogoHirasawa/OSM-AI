# OSM AI - QGIS Plugin

自然言語でOpenStreetMapデータを取得できるQGISプラグインです。

## 概要

**OSM AI**は、チャット形式でOpenStreetMapデータを検索・取得できるQGISプラグインです。LLM（OpenAI API）を使用してOverpass QLクエリを自動生成し、OSMデータをQGISレイヤとして追加します。

## 主な機能

### 🤖 自然言語によるデータ検索
- **日本語・英語など多言語対応**：QGISの言語設定に応じて自動的にUIの言語が切り替わります
- **会話形式のインターフェース**：チャットのように自然に指示を入力できます

### 💬 チャット機能
- **複数タブ対応**：異なる検索タスクを複数のタブで並行して実行
- **履歴保持**：各タブでチャット履歴を保持し、文脈を理解した検索が可能
- **処理状況の可視化**：データ取得中は「考え中...」アニメーションで進捗を表示

### 🌍 柔軟な地理検索
1. **現在の表示範囲で検索**：マップビューのバウンディングボックスを自動検出
2. **地名指定検索**：「横浜市の区役所」「渋谷区のカフェ」など、地名を含めた検索が可能

### ⌨️ 便利なショートカット
- **Enter**または**Command+Enter**でメッセージ送信（設定で選択可能）
- 効率的な操作が可能

## 必要な環境

- **QGIS**: 3.x 以上
- **Python**: 3.9 以上（QGIS標準環境に含まれる）
- **インターネット接続**：OpenAI APIとOverpass APIを使用
- **OpenAI APIキー**：[OpenAI Platform](https://platform.openai.com/)で取得

## インストール

### 方法1: ZIPファイルからインストール（推奨）

1. このプラグインのZIPファイルをダウンロードまたは作成します

2. QGISを起動し、メニューから **「プラグイン」→「プラグインの管理とインストール」** を開きます

3. **「ZIPからインストール」** タブを選択

4. ZIPファイルを選択してインストール

5. **「インストール済み」** タブで「OSM AI」にチェックを入れて有効化

### 方法2: 手動インストール

1. このディレクトリをQGISのプラグインディレクトリにコピーします：
   - **Windows**: `C:\Users\<username>\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\osm_ai`
   - **macOS**: `~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/osm_ai`
   - **Linux**: `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/osm_ai`

2. QGISを起動し、メニューから **「プラグイン」→「プラグインの管理とインストール」** を開きます

3. **「インストール済み」** タブで「OSM AI」を探し、チェックを入れて有効化

## セットアップ

### OpenAI APIキーの取得

1. [OpenAI Platform](https://platform.openai.com/)にアクセスしてアカウントを作成

2. [API Keys](https://platform.openai.com/api-keys)ページで新しいAPIキーを作成

3. APIキーをコピー（このキーは一度しか表示されないので注意）

### プラグインでAPIキーを設定

1. QGISでプラグインを有効化後、ツールバーの **OSM AIアイコン** をクリック

2. ドックウィジェットが表示されたら、右上の **⚙️ 設定アイコン** をクリック

3. **「OpenAI API Key」** フィールドにAPIキーを貼り付け

4. **「Send Shortcut」** で好みのキーボードショートカットを選択：
   - **Enter**: Enterキーで送信（改行はShift+Enter）
   - **Command+Enter**: Command+Enter（Ctrl+Enter）で送信

5. **「OK」** をクリックして保存

> **💡 ヒント**: 環境変数 `OPENAI_API_KEY` を設定している場合は、プラグイン設定での入力は不要です。

## 使い方

### 基本的な使い方

1. **QGISでプロジェクトを開く**  
   調査したいエリアをマップビューに表示します

2. **プラグインを起動**  
   ツールバーの **OSM AIアイコン** をクリック、またはメニューから **「プラグイン」→「OSM AI」** を選択

3. **自然言語で検索**  
   入力欄に自然言語で指示を入力します

   **例**：
   - 「コンビニを取得」
   - 「この範囲の公園を表示」
   - 「カフェを検索」
   - 「Get all convenience stores」
   - 「Show me cafes in this area」

4. **送信**  
   - **Sendボタン** をクリック
   - または **Enter**（または**Command+Enter**）を押す

5. **データが自動追加される**  
   - プラグインがOverpass QLクエリを自動生成
   - Overpass APIからOSMデータを取得
   - QGISレイヤパネルに新しいレイヤが追加される

### 地名を指定した検索

現在のマップビュー範囲に関わらず、特定の地名を指定して検索できます：

**例**：
- 「横浜市の区役所を取得」
- 「渋谷区のコンビニを表示」
- 「Get hospitals in Tokyo」
- 「Show me parks in Shibuya」

### マルチタブ機能

複数の検索タスクを並行して実行できます：

1. **新しいタブを作成**: 入力欄の上部にある **➕ アイコン** をクリック

2. **タブを切り替え**: タブをクリックして切り替え

3. **タブを閉じる**: タブの **✕ アイコン** をクリック

各タブは独立したチャット履歴を持ち、文脈を理解した会話が可能です。

### チャット機能

OSM AIは単なるデータ検索ツールではなく、会話形式で使えます：

- **あいさつ**: 「こんにちは」と話しかけると返答します
- **質問**: 「このプラグインの使い方は？」と聞くこともできます
- **文脈理解**: 前の会話を覚えているので、「もっと詳しく」などの指示も可能

## 設定

### キーボードショートカット

**設定画面**（⚙️ アイコン）から送信ショートカットを選択できます：

- **Enter**: 
  - メッセージ送信: **Enter**
  - 改行: **Shift+Enter**
  
- **Command+Enter** (推奨):
  - メッセージ送信: **Command+Enter**（Mac）または **Ctrl+Enter**（Windows/Linux）
  - 改行: **Enter**

## トラブルシューティング

### 「APIキーが見つかりません」エラー

**原因**: OpenAI APIキーが設定されていません

**解決方法**:
1. プラグインの設定画面（⚙️）を開く
2. OpenAI API Keyを入力
3. 有効なAPIキーであることを確認（[OpenAI Platform](https://platform.openai.com/api-keys)で確認）

### 「Overpass API request failed: 400」エラー

**原因**: 生成されたクエリが不正、または検索範囲が不適切です

**解決方法**:
1. より具体的な指示を入力してみる
2. 地名を含めた検索を試す（例: 「東京都のカフェ」）
3. マップをズームインしてから再試行

### データが取得できない

**原因**: Overpass APIの負荷制限、またはデータ量が多すぎます

**解決方法**:
1. インターネット接続を確認
2. 数分待ってから再試行（短時間に連続リクエストするとブロックされます）
3. マップをズームインして検索範囲を狭める
4. より具体的なカテゴリを指定（例: 「お店」→「コンビニ」）

### レイヤが表示されない

**原因**: データの範囲が現在のビューから外れています

**解決方法**:
1. QGISメッセージバーにエラーメッセージがないか確認
2. レイヤパネルで取得したレイヤを右クリック
3. **「レイヤの領域にズーム」** を選択

### プラグインが起動しない

**原因**: インストールが不完全、またはPython環境の問題です

**解決方法**:
1. QGISを再起動
2. プラグインを無効化してから再度有効化
3. プラグインを再インストール
4. QGISのPythonコンソールでエラーメッセージを確認

## 技術情報

### 使用しているAPI

- **OpenAI API**: GPT-4o-miniモデルを使用してOverpass QLクエリを生成
- **Overpass API**: OpenStreetMapデータを取得

### ディレクトリ構成

```
osm_ai/
├── __init__.py              # プラグインエントリポイント
├── metadata.txt             # プラグインメタデータ
├── osm_ai_plugin.py         # プラグイン本体
├── icon.png                 # プラグインアイコン
├── resources.qrc            # Qtリソース定義
├── resources.py             # Qtリソース（生成ファイル）
├── core/                    # コアロジック
│   ├── __init__.py
│   ├── settings.py          # 設定管理（APIキー、ショートカット）
│   ├── llm_client.py        # OpenAI API呼び出し
│   ├── overpass_client.py   # Overpass API呼び出し
│   └── qgis_utils.py        # QGIS統合（レイヤ追加など）
└── ui/                      # ユーザーインターフェース
    ├── __init__.py
    ├── osm_ai.ui            # Qt Designer UIファイル
    ├── osm_ai_form.py       # 生成されたUIコード
    └── icon/                # SVGアイコン素材
        ├── agent.svg
        ├── user.svg
        ├── plus.svg
        ├── xmark.svg
        └── sent.svg
```

### 依存関係

- `qgis.core` - QGIS Core API
- `qgis.PyQt` - PyQt5（QGIS標準環境に含まれる）
- `requests` - HTTP通信（QGIS標準環境に含まれる）

すべての依存関係はQGIS標準環境に含まれているため、追加のインストールは不要です。

## よくある質問（FAQ）

**Q: OpenAI API以外のLLM（Claude、Geminiなど）は使えますか？**  
A: 現在はOpenAI API専用です。将来的には他のプロバイダーにも対応予定です。

**Q: APIの利用料金はかかりますか？**  
A: はい。OpenAI APIは従量課金制です。ただし、GPT-4o-miniモデルは非常に安価（1Mトークンあたり$0.15程度）です。通常の使用では月額数十円程度です。

**Q: オフラインで使えますか？**  
A: いいえ。OpenAI APIとOverpass APIへのインターネット接続が必要です。

**Q: 取得できるデータの種類は？**  
A: OpenStreetMapに存在するあらゆるデータ（POI、道路、建物、土地利用など）が取得可能です。

**Q: 英語以外の言語でも使えますか？**  
A: はい。日本語、英語、中国語、スペイン語など多言語に対応しています。QGISの言語設定に応じて自動的にUIが切り替わります。

## ライセンス

このプラグインはオープンソースソフトウェアです。

## 謝辞

このプラグインは以下のサービスとプロジェクトを使用しています：

- [OpenStreetMap](https://www.openstreetmap.org/) - オープンな地図データ
- [Overpass API](https://overpass-api.de/) - OSMデータクエリサービス
- [OpenAI API](https://openai.com/api/) - 自然言語処理
- [QGIS](https://qgis.org/) - オープンソースGISソフトウェア

## サポート

バグレポート、機能要望、質問などがあれば、お気軽にお問い合わせください。

---

**Enjoy mapping with OSM AI! 🗺️✨**
